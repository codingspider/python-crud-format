CALL_TYPE = (
    (1, 'Incoming'),
    (2, 'Outgoing'),
)

TYPE = (
    ('Fees', 'Fees'),
    ('Study', 'Study'),
    ('Teacher', 'Teacher'),
    ('Sports', 'Sports'),
    ('Transport', 'Transport'),
    ('Hostel', 'Hostel'),
    ('Front Site', 'Front Site'),
    ('Others', 'Others'),
)

choice_status = (
    ('0', 'Deleted'),
    ('2', 'Active')
)

